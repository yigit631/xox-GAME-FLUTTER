import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'XOX Game',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: TicTacToe(),
    );
  }
}

class TicTacToe extends StatefulWidget {
  @override
  _TicTacToeState createState() => _TicTacToeState();
}

class _TicTacToeState extends State<TicTacToe> {
  List<String> board = List.filled(9, '');
  bool isXTurn = true; // X'in sırası mı kontrolü
  bool isTwoPlayerMode = true; // İki oyunculu mod varsayılan
  String resultMessage = ''; // Oyun sonucunu göstermek için

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('XOX Game'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (resultMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Text(
                  resultMessage,
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.redAccent,
                  ),
                ),
              ),
            Container(
              decoration: BoxDecoration(
                color: Colors.teal[50],
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 4,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 1,
                ),
                shrinkWrap: true,
                itemCount: 9,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () => _onTileTapped(index),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.teal[900]!),
                      ),
                      child: Center(
                        child: Text(
                          board[index],
                          style: TextStyle(
                            fontSize: 48,
                            fontWeight: FontWeight.bold,
                            color: board[index] == 'X'
                                ? Colors.blueAccent
                                : Colors.redAccent,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _resetGame,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    backgroundColor: Colors.teal[800],
                    textStyle: TextStyle(fontSize: 18),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text("Restart"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      isTwoPlayerMode = true;
                      _resetGame();
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                    backgroundColor: Colors.blueAccent,
                    textStyle: TextStyle(fontSize: 18),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text("İki Oyuncu"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      isTwoPlayerMode = false;
                      _resetGame();
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                    backgroundColor: Colors.redAccent,
                    textStyle: TextStyle(fontSize: 18),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text("Bilgisayara Karşı"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _onTileTapped(int index) {
    if (board[index] == '' && resultMessage == '') {
      setState(() {
        board[index] = isXTurn ? 'X' : 'O';

        if (isTwoPlayerMode) {
          // İki oyunculu modda sırayı değiştir
          isXTurn = !isXTurn;
        } else {
          // Bilgisayara karşı modda oyuncu X ve bilgisayar O
          if (!checkWinner()) {
            _computerMove();
          }
        }

        checkWinner();
      });
    }
  }

  void _computerMove() {
    List<int> emptyTiles = [];
    for (int i = 0; i < board.length; i++) {
      if (board[i] == '') {
        emptyTiles.add(i);
      }
    }

    if (emptyTiles.isNotEmpty) {
      int randomIndex = Random().nextInt(emptyTiles.length);
      int chosenTile = emptyTiles[randomIndex];
      setState(() {
        board[chosenTile] = 'O';
      });
    }
  }

  bool checkWinner() {
    // Oyun bitişi kontrolü: 8 olası kazanan kombinasyonu
    List<List<int>> winningCombinations = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];

    for (var combo in winningCombinations) {
      if (board[combo[0]] != '' &&
          board[combo[0]] == board[combo[1]] &&
          board[combo[0]] == board[combo[2]]) {
        setState(() {
          resultMessage = '${board[combo[0]]} kazandı!';
        });
        return true;
      }
    }

    if (!board.contains('')) {
      setState(() {
        resultMessage = 'Berabere!';
      });
      return true;
    }

    return false;
  }

  void _resetGame() {
    setState(() {
      board = List.filled(9, '');
      isXTurn = true;
      resultMessage = '';
    });
  }
}
