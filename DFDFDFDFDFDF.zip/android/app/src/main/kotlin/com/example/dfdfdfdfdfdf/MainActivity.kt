package com.example.dfdfdfdfdfdf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
